
function agregarAlumno(nombre, apellido, email, dni) {
  guardarEnLS(dni,
    {
      nombre: nombre,
      apellido: apellido,
      email: email
    }
  );
}

function buscarAlumno(dni) {
  return (buscarEnLS(dni) !== null);
}