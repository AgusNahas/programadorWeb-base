function guardarEnLS(key, datos) {
  var datosEnJSON = JSON.stringify(datos);
  localStorage.setItem(key, datosEnJSON);
}

function buscarEnLS(key) {
  var dato = localStorage.getItem(key);
  if (dato != undefined) {
    return JSON.parse(dato);
  } else return null
}