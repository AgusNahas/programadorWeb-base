
// Botones
var addStudentButtonNode = document.getElementById('addStudentButton')
var deleteStudentButtonNode = document.getElementById('deleteStudentButton')

// Texto
var campoNombre = document.getElementById('firstName')
var campoApellido = document.getElementById('lastName')
var campoEmail = document.getElementById('email')
var campoDni = document.getElementById('dni')

addStudentButtonNode.onclick = clickAgregarAlumno

function clickAgregarAlumno(event) {
  if (!buscarAlumno(parseInt(campoDni.value)))
    agregarAlumno(campoNombre.value, campoApellido.value, campoEmail.value, parseInt(campoDni.value))
}

deleteStudentButtonNode.onclick = clickEliminarAlumno

function clickEliminarAlumno(event) {

}
