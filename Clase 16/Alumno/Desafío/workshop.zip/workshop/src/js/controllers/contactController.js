function contactController(){
    console.log('Se cargo contacto')
}

export default contactController